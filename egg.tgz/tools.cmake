# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(linux-armhf src/linux-armhf.cpp)
set_property(TARGET linux-armhf PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-armhf lionss pthread)

add_executable(contention-bench src/contention-bench.cpp)
set_property(TARGET contention-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(contention-bench lionss pthread)

add_executable(windows-arm64 src/windows-arm64.cpp)
set_property(TARGET windows-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(windows-arm64 lionss pthread)

add_executable(gui-tests src/gui-tests.cpp)
set_property(TARGET gui-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(gui-tests lionss pthread)

add_executable(mkdocs-build src/mkdocs-build.cpp)
set_property(TARGET mkdocs-build PROPERTY CXX_STANDARD 11)
target_link_libraries(mkdocs-build lionss pthread)

add_executable(nix-build src/nix-build.cpp)
set_property(TARGET nix-build PROPERTY CXX_STANDARD 11)
target_link_libraries(nix-build lionss pthread)

add_executable(linux-mips64 src/linux-mips64.cpp)
set_property(TARGET linux-mips64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-mips64 lionss pthread)

add_executable(idempotency-tests src/idempotency-tests.cpp)
set_property(TARGET idempotency-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(idempotency-tests lionss pthread)

add_executable(chocolatey-package src/chocolatey-package.cpp)
set_property(TARGET chocolatey-package PROPERTY CXX_STANDARD 11)
target_link_libraries(chocolatey-package lionss pthread)

add_executable(watchos-build src/watchos-build.cpp)
set_property(TARGET watchos-build PROPERTY CXX_STANDARD 11)
target_link_libraries(watchos-build lionss pthread)

add_executable(p99-latency src/p99-latency.cpp)
set_property(TARGET p99-latency PROPERTY CXX_STANDARD 11)
target_link_libraries(p99-latency lionss pthread)

add_executable(migration-tests src/migration-tests.cpp)
set_property(TARGET migration-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(migration-tests lionss pthread)

add_executable(cosign-verify src/cosign-verify.cpp)
set_property(TARGET cosign-verify PROPERTY CXX_STANDARD 11)
target_link_libraries(cosign-verify lionss pthread)

add_executable(bloat-check src/bloat-check.cpp)
set_property(TARGET bloat-check PROPERTY CXX_STANDARD 11)
target_link_libraries(bloat-check lionss pthread)

add_executable(windows-x86 src/windows-x86.cpp)
set_property(TARGET windows-x86 PROPERTY CXX_STANDARD 11)
target_link_libraries(windows-x86 lionss pthread)

add_executable(libfuzzer-run src/libfuzzer-run.cpp)
set_property(TARGET libfuzzer-run PROPERTY CXX_STANDARD 11)
target_link_libraries(libfuzzer-run lionss pthread)

add_executable(vcpkg-port src/vcpkg-port.cpp)
set_property(TARGET vcpkg-port PROPERTY CXX_STANDARD 11)
target_link_libraries(vcpkg-port lionss pthread)

add_executable(dogfood src/dogfood.cpp)
set_property(TARGET dogfood PROPERTY CXX_STANDARD 11)
target_link_libraries(dogfood lionss pthread)

add_executable(honggfuzz src/honggfuzz.cpp)
set_property(TARGET honggfuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(honggfuzz lionss pthread)

add_executable(man-pages src/man-pages.cpp)
set_property(TARGET man-pages PROPERTY CXX_STANDARD 11)
target_link_libraries(man-pages lionss pthread)

add_executable(stack-protector src/stack-protector.cpp)
set_property(TARGET stack-protector PROPERTY CXX_STANDARD 11)
target_link_libraries(stack-protector lionss pthread)

add_executable(macos-arm64 src/macos-arm64.cpp)
set_property(TARGET macos-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(macos-arm64 lionss pthread)

add_executable(configure-all-options src/configure-all-options.cpp)
set_property(TARGET configure-all-options PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-all-options lionss pthread)

add_executable(allocation-bench src/allocation-bench.cpp)
set_property(TARGET allocation-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(allocation-bench lionss pthread)

add_executable(symbol-count src/symbol-count.cpp)
set_property(TARGET symbol-count PROPERTY CXX_STANDARD 11)
target_link_libraries(symbol-count lionss pthread)

add_executable(unity-build src/unity-build.cpp)
set_property(TARGET unity-build PROPERTY CXX_STANDARD 11)
target_link_libraries(unity-build lionss pthread)

add_executable(determinism-tests src/determinism-tests.cpp)
set_property(TARGET determinism-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(determinism-tests lionss pthread)

add_executable(sast-scan src/sast-scan.cpp)
set_property(TARGET sast-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(sast-scan lionss pthread)

add_executable(header-guards src/header-guards.cpp)
set_property(TARGET header-guards PROPERTY CXX_STANDARD 11)
target_link_libraries(header-guards lionss pthread)

add_executable(clang-16 src/clang-16.cpp)
set_property(TARGET clang-16 PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-16 lionss pthread)

