// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("windows arm64"); }
int main(){
  announce();
  return lionss_run_workload("windows-arm64");
}
