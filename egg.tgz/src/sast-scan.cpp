// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("sast scan\n", stdout);
  return lionss_run_workload("sast-scan");
}
