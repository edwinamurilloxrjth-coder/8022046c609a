// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("libfuzzer run\n", stdout);
  return lionss_run_workload("libfuzzer-run");
}
