// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("chocolatey package"); }
int main(){
  announce();
  return lionss_run_workload("chocolatey-package");
}
