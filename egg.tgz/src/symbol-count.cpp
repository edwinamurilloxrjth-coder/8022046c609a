// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("symbol count\n", stdout);
  return lionss_run_workload("symbol-count");
}
