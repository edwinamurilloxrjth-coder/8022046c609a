// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("gui tests\n", stdout);
  return lionss_run_workload("gui-tests");
}
