// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("watchos build\n", stdout);
  return lionss_run_workload("watchos-build");
}
